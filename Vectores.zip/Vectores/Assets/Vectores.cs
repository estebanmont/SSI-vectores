using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[System.Serializable]
public struct Vectores
{
    public float x, y;
    public Vectores SumarVectores(Vectores vector1, Vectores vector2)
    {
        Vectores c = new Vectores();
        c.x = vector1.x + vector2.x;
        c.y = vector1.y + vector2.y;
        return c;
    }

    public Vectores RestarVectores(Vectores vector1, Vectores vector2)
    {
        Vectores c = new Vectores();
        c.x = vector1.x - vector2.x;
        c.y = vector1.y - vector2.y;
        return c;
    }

    public Vectores MultVectores(Vectores vector, float escalar)
    {
        Vectores c = new Vectores();
        c.x = vector.x * escalar;
        c.y = vector.y *escalar;
        return c;
    }

    public void Draw()
    {
        Vector2 vector1 = new Vector2(0,0);
        Vector2 vector2 = new Vector2(this.x, this.y);
        Debug.DrawLine(vector1, vector2);


    }
    public void Draw(Vectores inicio)
    {
        Vector2 vector1 = new Vector2(inicio.x, inicio.y);
        Vector2 vector2 = new Vector2(this.x+inicio.x, this.y+inicio.y);
        Debug.DrawLine(vector1, vector2);


    }

    public float Magnitud()
    {
        float c;
        c = this.x * this.x + this.y * this.y;
        c = Mathf.Sqrt(c);
        return c;
    }
    public override string ToString()
    {
        return "(" + "," + this.y + ")";
    }

    public Vectores Normalizar()
    {
        Vectores c = new Vectores();
        float d;
        d = 1 / this.Magnitud();
        c.x = this.x * d;
        c.y = this.y * d;
        return c;
    }

    public Vectores Lerp (Vectores final, float escalar)
    {
        Vectores c = new Vectores();
        c = c.SumarVectores(this, c.MultVectores(c.RestarVectores(final, this), escalar));
        return c;
    }

    /*public static MyVector2D operator+(MyVector2D a , MyVector2D b)
    {
        return new MyVector2D(a.X + b.X , a.Y + b.Y);
    }

    public static MyVector2D operator -(MyVector2D a, MyVector2D b)
    {
        return new MyVector2D(a.X - b.X , a.Y - b.Y);
    }

    public static MyVector2D operator*(MyVector2D a , float escalar)
    {
        return new MyVector2D(a.X* escalar , a.Y * escalar);
    }

    public static MyVector2D operator*(float escalar,MyVector2D a )
    {
        return new MyVector2D(a.X* escalar , a.Y * escalar);
    }
    
     public static MyVector2D operator/(MyVector2D a, float escalar )
    {
        return new MyVector2D(a.X/ escalar , a.Y / escalar);
    }

    */

}



